//
//  GetTableViewData.h
//  XLNetwork
//
//  Created by Shelin on 15/11/10.
//  Copyright © 2015年 GreatGate. All rights reserved.
//

#import "XLDataService.h"

@interface GetTableViewData : XLDataService

@end
