//
//  ViewController.h
//  YYImageClipViewController
//
//  Created by 杨健 on 16/7/8.
//  Copyright © 2016年 杨健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

