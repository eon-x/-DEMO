//
//  DazViewController.h
//  FFEmitterDemo
//
//  Created by iObitLXF on 1/22/13.
//  Copyright (c) 2013 iObitLXF. All rights reserved.
//  拿的别人的这个

#import <UIKit/UIKit.h>
#import <QuartzCore/CoreAnimation.h>

@interface DazViewController : UIViewController
@property (strong) CAEmitterLayer *dazLayer;
@end
