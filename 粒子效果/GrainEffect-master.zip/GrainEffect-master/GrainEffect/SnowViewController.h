//
//  EmitterFirstViewController.h
//  FFEmitterDemo
//
//  Created by iObitLXF on 1/22/13.
//  Copyright (c) 2013 iObitLXF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/CoreAnimation.h>

@interface SnowViewController : UIViewController
{
     CAEmitterLayer *flakeLayer;
}
@end
